(function () {
  const STORAGE_KEY = "cafecart_cart_v1";
  function getCart() {
    try {
      const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
      return Array.isArray(data) ? data.filter(i => i && Number.isInteger(Number(i.id)) && Number(i.qty) > 0) : [];
    } catch (_) { return []; }
  }
  function saveCart(cart) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
    updateCount();
  }
  function money(value) { return "₹" + Number(value || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 }); }
  function escapeHTML(value) {
    return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
  }
  function updateCount() {
    const count = getCart().reduce((sum, item) => sum + Number(item.qty || 0), 0);
    document.querySelectorAll("[data-cart-count]").forEach(el => el.textContent = count);
  }
  function addItem(id, name, price) {
    const cart = getCart();
    const found = cart.find(item => Number(item.id) === Number(id));
    if (found) found.qty = Math.min(20, Number(found.qty) + 1);
    else cart.push({ id: Number(id), name: String(name), price: Number(price), qty: 1 });
    saveCart(cart);
    const btn = document.querySelector(`[data-add-to-cart][data-id="${id}"]`);
    if (btn) {
      const old = btn.textContent;
      btn.textContent = "✓";
      btn.classList.add("added");
      setTimeout(() => { btn.textContent = old; btn.classList.remove("added"); }, 850);
    }
  }
  function setupFilters() {
    const search = document.getElementById("product-search");
    const chips = Array.from(document.querySelectorAll("[data-filter]"));
    const cards = Array.from(document.querySelectorAll("[data-product-card]"));
    if (!search || !cards.length) return;
    let category = "All";
    function apply() {
      const query = search.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {
        const matches = card.dataset.name.includes(query) && (category === "All" || card.dataset.category === category);
        card.hidden = !matches;
        if (matches) visible++;
      });
      document.getElementById("results-count").textContent = visible;
      document.getElementById("empty-search").hidden = visible !== 0;
    }
    search.addEventListener("input", apply);
    chips.forEach(chip => chip.addEventListener("click", () => {
      category = chip.dataset.filter;
      chips.forEach(c => c.classList.toggle("active", c === chip));
      apply();
    }));
  }
  function setupMobileNav() {
    const toggle = document.querySelector(".menu-toggle");
    const nav = document.querySelector(".nav-links");
    if (!toggle || !nav) return;
    toggle.addEventListener("click", () => {
      const isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(isOpen));
    });
  }
  document.addEventListener("click", event => {
    const button = event.target.closest("[data-add-to-cart]");
    if (button) addItem(button.dataset.id, button.dataset.name, button.dataset.price);
  });
  document.addEventListener("DOMContentLoaded", () => {
    updateCount();
    setupFilters();
    setupMobileNav();
  });
  window.CafeCart = {
    getCart,
    clearCart: () => { localStorage.removeItem(STORAGE_KEY); updateCount(); },
    money,
    escapeHTML
  };
})();
